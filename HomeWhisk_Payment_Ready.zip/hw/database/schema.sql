CREATE DATABASE IF NOT EXISTS homewhisk;
USE homewhisk;

CREATE TABLE IF NOT EXISTS products (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255) NOT NULL,
 category VARCHAR(100) NOT NULL,
 price DOUBLE NOT NULL,
 image VARCHAR(1000) NOT NULL,
 description VARCHAR(1000)
);

INSERT INTO products(name,category,price,image,description) VALUES
('Chocolate Cake','Cakes',600,'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=700&q=85','Rich, moist homemade chocolate cake.'),
('Vanilla Cupcakes','Cupcakes',250,'https://images.unsplash.com/photo-1587668178277-295251f900ce?auto=format&fit=crop&w=700&q=85','Soft vanilla cupcakes.'),
('Chocolate Chip Cookies','Cookies',180,'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=700&q=85','Freshly baked cookies.'),
('Fudge Brownies','Brownies',220,'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=700&q=85','Fudgy homemade brownies.');
