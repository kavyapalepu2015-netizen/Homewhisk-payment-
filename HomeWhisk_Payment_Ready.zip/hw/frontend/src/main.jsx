import React, {useEffect, useState} from 'react'
import {createRoot} from 'react-dom/client'
import './styles.css'

const API = import.meta.env.VITE_API_BASE_URL || ''

const fallbackProducts = [
 {id:1,name:'Chocolate Cake',category:'Cakes',price:600,image:'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=700&q=85',description:'Rich, moist homemade chocolate cake.'},
 {id:2,name:'Vanilla Cupcakes',category:'Cupcakes',price:250,image:'https://images.unsplash.com/photo-1587668178277-295251f900ce?auto=format&fit=crop&w=700&q=85',description:'Soft vanilla cupcakes with homemade frosting.'},
 {id:3,name:'Chocolate Chip Cookies',category:'Cookies',price:180,image:'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=700&q=85',description:'Freshly baked cookies with chocolate chips.'},
 {id:4,name:'Fudge Brownies',category:'Brownies',price:220,image:'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=700&q=85',description:'Fudgy homemade brownies.'}
]

async function getProducts(){
  try { const r=await fetch(`${API}/api/products`); if(!r.ok) throw Error(); return await r.json() }
  catch { return fallbackProducts }
}

function App(){
 const [page,setPage]=useState('home')
 const [products,setProducts]=useState([])
 const [cart,setCart]=useState(()=>JSON.parse(localStorage.getItem('hw-cart')||'[]'))
 const [orders,setOrders]=useState([])
 const [selected,setSelected]=useState(null)
 const [query,setQuery]=useState('')
 const [category,setCategory]=useState('All')
 const [loading,setLoading]=useState(true)
 const [error,setError]=useState('')

 useEffect(()=>{getProducts().then(setProducts).finally(()=>setLoading(false))},[])
 useEffect(()=>localStorage.setItem('hw-cart',JSON.stringify(cart)),[cart])

 const filtered=products.filter(p=>(category==='All'||p.category===category)&&p.name.toLowerCase().includes(query.toLowerCase()))
 const total=cart.reduce((s,x)=>s+x.price*x.quantity,0)
 const openProduct=p=>{setSelected({...p,quantity:1,flavor:'Chocolate',size:'6 inch',message:'',eggless:false,notes:'',deliveryDate:new Date(Date.now()+5*864e5).toISOString().slice(0,10)});setPage('product')}
 const addCart=item=>{setCart(c=>[...c,item]);setPage('cart')}
 const remove=i=>setCart(c=>c.filter((_,x)=>x!==i))

 async function placeOrder(){
   if(!cart.length)return
   const first=cart[0]
   const amount=total+50
   try{
     const paymentResponse=await fetch(`${API}/api/payments/order`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount})})
     if(!paymentResponse.ok) throw Error('Payment gateway is not configured')
     const paymentOrder=await paymentResponse.json()
     if(!window.Razorpay) throw Error('Razorpay Checkout failed to load')
     await new Promise((resolve,reject)=>{
       const options={
         key:paymentOrder.keyId,
         amount:paymentOrder.amount,
         currency:paymentOrder.currency,
         name:'HomeWhisk',
         description:'Homemade treats order',
         order_id:paymentOrder.orderId,
         prefill:{name:'HomeWhisk Customer',email:'customer@example.com',contact:'9876543210'},
         theme:{color:'#8b5e3c'},
         handler:async response=>{
           try{
             const verify=await fetch(`${API}/api/payments/verify`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({razorpayOrderId:response.razorpay_order_id,razorpayPaymentId:response.razorpay_payment_id,razorpaySignature:response.razorpay_signature})})
             if(!verify.ok) throw Error('Payment verification failed')
             resolve(response)
           }catch(e){reject(e)}
         },
         modal:{ondismiss:()=>reject(Error('Payment cancelled'))}
       }
       new window.Razorpay(options).open()
     })
   }catch(e){
     alert(e.message==='Payment cancelled'?'Payment cancelled. No order was placed.':'Payment is not ready. Add Razorpay test keys to the backend environment before accepting real payments.')
     return
   }
   const payload={
     customer:{name:'HomeWhisk Customer',phone:'9876543210',email:'customer@example.com',address:'Kanigiri, Andhra Pradesh'},
     items:cart.map(x=>({productId:x.id,quantity:x.quantity,customization:`Flavor: ${x.flavor}; Size: ${x.size}; Message: ${x.message||'—'}; Eggless: ${x.eggless?'Yes':'No'}; Notes: ${x.notes||'—'}`})),
     deliveryDate:first.deliveryDate
   }
   try{
     const r=await fetch(`${API}/api/orders`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
     if(!r.ok) throw Error('Order API error')
     const order=await r.json();setOrders(o=>[order,...o]);setCart([]);setPage('confirmation')
   }catch(e){
     const order={id:'DEMO-'+Date.now(),total:total+50,status:'CONFIRMED',deliveryDate:first.deliveryDate,items:cart}
     setOrders(o=>[order,...o]);setCart([]);setPage('confirmation')
   }
 }

 return <div className="app">
  <header><div className="brand" onClick={()=>setPage('home')}>🥄🏠 <b>HomeWhisk</b></div>
   <nav>
    <button onClick={()=>setPage('home')}>Home</button>
    <button onClick={()=>setPage('cart')}>Cart <span className="badge">{cart.reduce((s,x)=>s+x.quantity,0)}</span></button>
    <button onClick={()=>setPage('track')}>Orders</button>
    <button onClick={()=>setPage('baker')}>Baker</button>
   </nav>
  </header>

  <main>
   {page==='home'&&<><section className="hero"><div><small>HOMEMADE • FRESH • LOVINGLY BAKED</small><h1>Homemade treats for every moment.</h1><p>Discover cakes, cupcakes, cookies and brownies made by local home bakers.</p><button onClick={()=>document.getElementById('products').scrollIntoView({behavior:'smooth'})}>Order Now</button></div><img src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=85"/></section>
    <input className="search" placeholder="🔎 Search homemade treats..." value={query} onChange={e=>setQuery(e.target.value)}/>
    <div className="cats">{['All','Cakes','Cupcakes','Cookies','Brownies'].map(c=><button className={category===c?'chosen':''} onClick={()=>setCategory(c)} key={c}>{c==='All'?'✨':c==='Cakes'?'🎂':c==='Cupcakes'?'🧁':c==='Cookies'?'🍪':'🍫'} {c}</button>)}</div>
    <h2 id="products">Popular Products</h2>
    {loading?<div className="state">Loading delicious treats...</div>:error?<div className="state error">{error}</div>:<div className="grid">{filtered.map(p=><article className="card" key={p.id}><img src={p.image}/><div><h3>{p.name}</h3><p>{p.description}</p><div className="row"><b>₹{p.price}</b><button className="small" onClick={()=>openProduct(p)}>Customize</button></div></div></article>)}</div>}
   </>}

   {page==='product'&&selected&&<Product p={selected} back={()=>setPage('home')} add={addCart}/>}
   {page==='cart'&&<section><h1>My Cart</h1>{!cart.length?<div className="state"><h2>Your cart is empty 🧁</h2><button onClick={()=>setPage('home')}>Browse Treats</button></div>:<><div className="cart">{cart.map((x,i)=><div className="cartItem" key={i}><img src={x.image}/><div><h3>{x.name}</h3><p>Qty: {x.quantity} • {x.flavor} • {x.size}</p><small>{x.message||'No cake message'}</small></div><b>₹{x.price*x.quantity}</b><button className="remove" onClick={()=>remove(i)}>Remove</button></div>)}</div><div className="checkout"><p>Subtotal <b>₹{total}</b></p><p>Delivery <b>₹50</b></p><h2>Total <b>₹{total+50}</b></h2><button onClick={placeOrder}>Pay ₹{total+50} & Place Order</button></div></>}</section>}
   {page==='confirmation'&&<section className="panel center"><div className="check">✓</div><h1>Order Confirmed!</h1><p>Your homemade treats are being prepared with love.</p><button onClick={()=>setPage('track')}>Track Order</button></section>}
   {page==='track'&&<Track orders={orders}/>}
   {page==='baker'&&<Baker orders={orders} setOrders={setOrders}/>}
  </main>
 </div>
}

function Product({p,back,add}){
 const [x,setX]=useState(p)
 const update=(k,v)=>setX({...x,[k]:v})
 return <section><button className="back" onClick={back}>← Back</button><div className="detail"><img src={x.image}/><div className="panel"><h1>{x.name}</h1><h2>₹{x.price}</h2><p>{x.description}</p>
  <label>Flavor<select value={x.flavor} onChange={e=>update('flavor',e.target.value)}><option>Chocolate</option><option>Vanilla</option><option>Red Velvet</option><option>Butterscotch</option></select></label>
  <label>Size<select value={x.size} onChange={e=>update('size',e.target.value)}><option>6 inch</option><option>8 inch</option><option>10 inch</option></select></label>
  <label>Cake Message<input value={x.message} onChange={e=>update('message',e.target.value)} placeholder="Happy Birthday!"/></label>
  <label>Delivery Date<input type="date" value={x.deliveryDate} onChange={e=>update('deliveryDate',e.target.value)}/></label>
  <label>Quantity<input type="number" min="1" value={x.quantity} onChange={e=>update('quantity',Math.max(1,+e.target.value))}/></label>
  <label>Special Instructions<textarea value={x.notes} onChange={e=>update('notes',e.target.value)}/></label>
  <button className="full" onClick={()=>add(x)}>Add to Cart</button>
 </div></div></section>
}

function Track({orders}){
 const o=orders[0]
 if(!o)return <div className="state"><h2>No orders yet 📦</h2><p>Place an order to see delivery tracking here.</p></div>
 const steps=['Order Placed','Confirmed','Preparing','Out for Delivery','Delivered']
 const idx={PENDING:0,CONFIRMED:1,PREPARING:2,OUT_FOR_DELIVERY:3,DELIVERED:4}[o.status]??1
 return <section className="panel track"><h1>Track #{o.id}</h1><p>Delivery date: {o.deliveryDate}</p>{steps.map((s,i)=><div className={'step '+(i<idx?'done':i===idx?'current':'')} key={s}><span>✓</span><div><b>{s}</b><small>{i===idx?'Current status':''}</small></div></div>)}</section>
}

function Baker({orders,setOrders}){
 const advance=i=>{const flow=['PENDING','CONFIRMED','PREPARING','OUT_FOR_DELIVERY','DELIVERED'];const o=orders[i];const n=Math.min(flow.indexOf(o.status)+1,4);setOrders(a=>a.map((x,k)=>k===i?{...x,status:flow[n]}:x))}
 return <section><h1>Baker Dashboard</h1><div className="stats"><div>📦<b>{orders.length}</b><small>Total Orders</small></div><div>🟠<b>{orders.filter(o=>o.status==='PENDING').length}</b><small>Pending</small></div><div>🟣<b>{orders.filter(o=>o.status==='PREPARING').length}</b><small>Preparing</small></div><div>🟢<b>{orders.filter(o=>o.status==='DELIVERED').length}</b><small>Delivered</small></div></div><div className="panel table"><h2>Recent Orders</h2>{orders.length?<table><thead><tr><th>Order</th><th>Total</th><th>Status</th><th>Action</th></tr></thead><tbody>{orders.map((o,i)=><tr key={o.id}><td>#{o.id}</td><td>₹{o.total}</td><td>{o.status}</td><td><button className="small" onClick={()=>advance(i)}>Update</button></td></tr>)}</tbody></table>:<p>No orders yet.</p>}</div></section>
}

createRoot(document.getElementById('root')).render(<App/>)
