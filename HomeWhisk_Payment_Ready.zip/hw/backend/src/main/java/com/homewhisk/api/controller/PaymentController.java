package com.homewhisk.api.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class PaymentController {
    @Value("${razorpay.key-id:}") private String keyId;
    @Value("${razorpay.key-secret:}") private String keySecret;

    private final ObjectMapper mapper;
    private final HttpClient http = HttpClient.newHttpClient();

    public PaymentController(ObjectMapper mapper) { this.mapper = mapper; }

    @PostMapping("/order")
    public ResponseEntity<?> createPaymentOrder(@RequestBody PaymentOrderRequest request) throws Exception {
        if (keyId.isBlank() || keySecret.isBlank()) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of("message", "Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET."));
        }
        long amountPaise = Math.round(request.amount() * 100);
        if (amountPaise < 100) return ResponseEntity.badRequest().body(Map.of("message", "Minimum payment is ₹1."));

        String auth = Base64.getEncoder().encodeToString((keyId + ":" + keySecret).getBytes(StandardCharsets.UTF_8));
        String body = mapper.writeValueAsString(Map.of(
                "amount", amountPaise,
                "currency", "INR",
                "receipt", "HW_" + System.currentTimeMillis(),
                "notes", Map.of("source", "HomeWhisk")
        ));
        HttpRequest httpRequest = HttpRequest.newBuilder(URI.create("https://api.razorpay.com/v1/orders"))
                .header("Authorization", "Basic " + auth)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        HttpResponse<String> response = http.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() / 100 != 2) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Map.of("message", "Unable to create payment order."));
        }
        JsonNode order = mapper.readTree(response.body());
        return ResponseEntity.ok(Map.of("keyId", keyId, "orderId", order.get("id").asText(), "amount", amountPaise, "currency", "INR"));
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verify(@RequestBody VerifyPaymentRequest request) throws Exception {
        if (keySecret.isBlank()) return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of("message", "Payment verification is not configured."));
        String payload = request.razorpayOrderId() + "|" + request.razorpayPaymentId();
        String expected = hmacSha256(payload, keySecret);
        boolean valid = constantTimeEquals(expected, request.razorpaySignature());
        return valid ? ResponseEntity.ok(Map.of("verified", true))
                : ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("verified", false, "message", "Invalid payment signature."));
    }

    private static String hmacSha256(String value, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] digest = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder();
        for (byte b : digest) out.append(String.format("%02x", b));
        return out.toString();
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        return java.security.MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }

    public record PaymentOrderRequest(double amount) {}
    public record VerifyPaymentRequest(String razorpayOrderId, String razorpayPaymentId, String razorpaySignature) {}
}
