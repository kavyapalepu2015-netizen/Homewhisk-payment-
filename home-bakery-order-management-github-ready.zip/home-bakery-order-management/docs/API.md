# REST API

Base URL: `http://localhost:8080/api`

## Products
### GET /products
Returns all bakery products.

## Orders
### POST /orders
Creates an order.

Required fields:
- productId
- quantity
- deliveryDate
- deliveryAddress
- contactName
- contactPhone
- contactEmail

Optional:
- customization

### GET /orders
Returns all orders.

### GET /orders/{id}
Returns one order.

### PATCH /orders/{id}/status?status=CONFIRMED
Updates the baker-side delivery/order status.

Allowed status values:
`PENDING`, `CONFIRMED`, `BAKING`, `OUT_FOR_DELIVERY`, `DELIVERED`, `CANCELLED`
