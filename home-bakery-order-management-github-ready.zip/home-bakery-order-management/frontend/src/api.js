async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  })

  const data = await response.json().catch(() => ({}))
  if (!response.ok) {
    const error = new Error(data.message || 'Request failed')
    error.details = data.errors || {}
    error.status = response.status
    throw error
  }
  return data
}

export const api = {
  products: () => request('/api/products'),
  orders: () => request('/api/orders'),
  createOrder: (body) => request('/api/orders', { method: 'POST', body: JSON.stringify(body) }),
  updateStatus: (id, status) =>
    request(`/api/orders/${id}/status?status=${encodeURIComponent(status)}`, { method: 'PATCH' })
}
