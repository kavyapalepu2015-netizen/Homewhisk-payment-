import { useEffect, useMemo, useState } from 'react'
import { api } from './api'

const initialForm = {
  productId: '',
  quantity: 1,
  customization: '',
  deliveryDate: '',
  deliveryAddress: '',
  contactName: '',
  contactPhone: '',
  contactEmail: ''
}

const statuses = ['PENDING', 'CONFIRMED', 'BAKING', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED']

function money(value) {
  return `₹${Number(value).toFixed(2)}`
}

export default function App() {
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [form, setForm] = useState(initialForm)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [fieldErrors, setFieldErrors] = useState({})
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [search, setSearch] = useState('')

  useEffect(() => {
    Promise.all([api.products(), api.orders()])
      .then(([p, o]) => {
        setProducts(p)
        setOrders(o)
        if (p.length) setForm(f => ({ ...f, productId: String(p[0].id) }))
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  const selectedProduct = products.find(p => String(p.id) === String(form.productId))
  const estimatedTotal = useMemo(
    () => selectedProduct ? Number(selectedProduct.price) * Number(form.quantity || 0) : 0,
    [selectedProduct, form.quantity]
  )

  const filteredOrders = orders.filter(o =>
    `${o.id} ${o.product} ${o.contactName} ${o.status}`.toLowerCase().includes(search.toLowerCase())
  )

  function change(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
    setFieldErrors({ ...fieldErrors, [e.target.name]: '' })
    setError('')
  }

  async function submit(e) {
    e.preventDefault()
    setSubmitting(true)
    setError('')
    setMessage('')
    setFieldErrors({})
    try {
      const created = await api.createOrder({
        ...form,
        productId: Number(form.productId),
        quantity: Number(form.quantity)
      })
      setOrders(prev => [created, ...prev])
      setSelectedOrder(created)
      setMessage(`Order #${created.id} confirmed successfully.`)
      setForm({ ...initialForm, productId: products[0] ? String(products[0].id) : '' })
    } catch (e) {
      setError(e.message)
      setFieldErrors(e.details || {})
    } finally {
      setSubmitting(false)
    }
  }

  async function updateStatus(id, status) {
    try {
      const updated = await api.updateStatus(id, status)
      setOrders(prev => prev.map(o => o.id === id ? updated : o))
      if (selectedOrder?.id === id) setSelectedOrder(updated)
    } catch (e) {
      setError(e.message)
    }
  }

  if (loading) return <div className="center">Loading bakery system…</div>

  return (
    <div className="app">
      <header>
        <div>
          <p className="eyebrow">HOME BAKERY</p>
          <h1>Freshly baked. Simply ordered.</h1>
          <p className="subtitle">Customer ordering and baker-side order management in one place.</p>
        </div>
        <span className="badge">REST API + JPA</span>
      </header>

      {message && <div className="alert success">{message}</div>}
      {error && <div className="alert error">{error}</div>}

      <main>
        <section className="card">
          <h2>Place an Order</h2>
          <form onSubmit={submit}>
            <label>Product
              <select name="productId" value={form.productId} onChange={change} required>
                {products.map(p => <option key={p.id} value={p.id}>{p.name} — {money(p.price)}</option>)}
              </select>
              {fieldErrors.productId && <small>{fieldErrors.productId}</small>}
            </label>

            <label>Quantity
              <input name="quantity" type="number" min="1" max="50" value={form.quantity} onChange={change} required />
              {fieldErrors.quantity && <small>{fieldErrors.quantity}</small>}
            </label>

            <label>Customization
              <textarea name="customization" value={form.customization} onChange={change}
                placeholder="Message, flavour, colour or other request" />
            </label>

            <label>Delivery Date
              <input name="deliveryDate" type="date" value={form.deliveryDate} onChange={change} required />
              {fieldErrors.deliveryDate && <small>{fieldErrors.deliveryDate}</small>}
            </label>

            <label>Delivery Address
              <textarea name="deliveryAddress" value={form.deliveryAddress} onChange={change}
                placeholder="Full delivery address" required />
              {fieldErrors.deliveryAddress && <small>{fieldErrors.deliveryAddress}</small>}
            </label>

            <div className="grid2">
              <label>Contact Name
                <input name="contactName" value={form.contactName} onChange={change} required />
              </label>
              <label>Phone
                <input name="contactPhone" value={form.contactPhone} onChange={change} required />
              </label>
            </div>

            <label>Email
              <input name="contactEmail" type="email" value={form.contactEmail} onChange={change} required />
            </label>

            <div className="total">Estimated Total <strong>{money(estimatedTotal)}</strong></div>
            <button disabled={submitting}>{submitting ? 'Placing order…' : 'Place Order'}</button>
          </form>
        </section>

        <section className="card">
          <h2>Order Confirmation</h2>
          {selectedOrder ? (
            <div className="confirmation">
              <div className="confirmationTop">
                <strong>Order #{selectedOrder.id}</strong>
                <span className={`status ${selectedOrder.status}`}>{selectedOrder.status.replaceAll('_', ' ')}</span>
              </div>
              <p><b>Product:</b> {selectedOrder.product} × {selectedOrder.quantity}</p>
              <p><b>Customization:</b> {selectedOrder.customization || 'None'}</p>
              <p><b>Delivery:</b> {selectedOrder.deliveryDate}</p>
              <p><b>Address:</b> {selectedOrder.deliveryAddress}</p>
              <p><b>Total:</b> {money(selectedOrder.total)}</p>
              <div className="timeline">
                {['PENDING','CONFIRMED','BAKING','OUT_FOR_DELIVERY','DELIVERED'].map(s =>
                  <div className={statuses.indexOf(selectedOrder.status) >= statuses.indexOf(s) ? 'step active' : 'step'} key={s}>
                    <span>●</span>{s.replaceAll('_',' ')}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <p className="muted">Your latest order confirmation will appear here.</p>
          )}
        </section>

        <section className="card full">
          <div className="sectionHead">
            <div><h2>Baker Order Management</h2><p className="muted">Review and update customer orders.</p></div>
            <input className="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search orders…" />
          </div>

          {filteredOrders.length === 0 ? <p className="muted">No orders found.</p> :
            <div className="tableWrap">
              <table>
                <thead><tr><th>ID</th><th>Customer</th><th>Product</th><th>Delivery</th><th>Total</th><th>Status</th></tr></thead>
                <tbody>
                  {filteredOrders.map(o => (
                    <tr key={o.id}>
                      <td>#{o.id}</td>
                      <td>{o.contactName}<br/><small>{o.contactPhone}</small></td>
                      <td>{o.product} × {o.quantity}</td>
                      <td>{o.deliveryDate}</td>
                      <td>{money(o.total)}</td>
                      <td>
                        <select value={o.status} onChange={e => updateStatus(o.id, e.target.value)}>
                          {statuses.map(s => <option key={s}>{s}</option>)}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>}
        </section>
      </main>

      <footer>Home Bakery Order Management System • Java 17 • Spring Boot • React • MySQL</footer>
    </div>
  )
}
