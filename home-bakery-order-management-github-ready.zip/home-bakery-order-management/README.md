# Home Bakery Order Management System

A GitHub-ready full-stack application for managing home bakery orders.

## Technology
- Java 17
- Spring Boot 3.5.x
- Spring Web
- Spring Data JPA / Hibernate
- MySQL
- React + Vite
- REST API
- Maven
- Git / GitHub

## Features
- Customer order form
- Product, quantity, customization, delivery date/address and contact details
- Server-side validation
- Order total calculation
- Order confirmation with customization summary
- Delivery status tracking
- Baker-side order management
- Status updates: PENDING, CONFIRMED, BAKING, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
- Responsive React UI
- Loading, success, validation and error states
- CORS configuration for local development
- Database persistence with JPA/Hibernate
- Health endpoint
- Sample products endpoint

## Project Structure

```text
home-bakery-order-management/
├── backend/
│   ├── pom.xml
│   └── src/main/java/com/bakery/
│       ├── BakeryApplication.java
│       ├── config/WebConfig.java
│       ├── controller/OrderController.java
│       ├── controller/ProductController.java
│       ├── dto/CreateOrderRequest.java
│       ├── dto/OrderResponse.java
│       ├── entity/Order.java
│       ├── entity/Product.java
│       ├── entity/OrderStatus.java
│       ├── exception/GlobalExceptionHandler.java
│       ├── exception/ResourceNotFoundException.java
│       ├── repository/OrderRepository.java
│       ├── repository/ProductRepository.java
│       └── service/OrderService.java
│   └── src/main/resources/application.properties
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── App.jsx
│       ├── api.js
│       ├── main.jsx
│       └── styles.css
└── .gitignore
```

## 1. Database

Create a MySQL database:

```sql
CREATE DATABASE bakery_db;
```

Update `backend/src/main/resources/application.properties` if your MySQL username/password differs.

Default:
- host: localhost
- port: 3306
- database: bakery_db
- username: root
- password: root

## 2. Run Backend

Requirements:
- JDK 17+
- Maven 3.9+

```bash
cd backend
mvn spring-boot:run
```

Backend:
`http://localhost:8080`

Health:
`GET http://localhost:8080/api/health`

Products:
`GET http://localhost:8080/api/products`

Orders:
`POST http://localhost:8080/api/orders`
`GET http://localhost:8080/api/orders`
`GET http://localhost:8080/api/orders/{id}`
`PATCH http://localhost:8080/api/orders/{id}/status?status=CONFIRMED`

## 3. Run Frontend

Requirements:
- Node.js 18+

```bash
cd frontend
npm install
npm run dev
```

Frontend:
`http://localhost:5173`

The Vite development proxy forwards `/api` requests to Spring Boot.

## 4. Example Order JSON

```json
{
  "productId": 1,
  "quantity": 2,
  "customization": "Chocolate message: Happy Birthday",
  "deliveryDate": "2026-10-10",
  "deliveryAddress": "12 Main Street, Nellore",
  "contactName": "Customer",
  "contactPhone": "9876543210",
  "contactEmail": "customer@example.com"
}
```

## HTTP Status Codes
- `201 Created` - order successfully created
- `200 OK` - successful read/update
- `400 Bad Request` - validation/invalid status
- `404 Not Found` - product/order does not exist
- `500 Internal Server Error` - unexpected server error

## GitHub Deployment

Create a GitHub repository, then:

```bash
git init
git add .
git commit -m "Initial home bakery order management system"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/home-bakery-order-management.git
git push -u origin main
```

Recommended meaningful commits:

```text
feat: add bakery order REST API
feat: add JPA entities and repositories
feat: add order validation and exception handling
feat: add React customer order form
feat: add baker order management
docs: add setup and API documentation
```

## Production Notes

For real deployment, set database credentials through environment variables/secrets instead of committing passwords. Replace `ddl-auto=update` with a migration tool such as Flyway before production use. Add authentication/authorization before exposing baker management publicly.
