package com.bakery;

import com.bakery.entity.Product;
import com.bakery.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;

@SpringBootApplication
public class BakeryApplication {
    public static void main(String[] args) {
        SpringApplication.run(BakeryApplication.class, args);
    }

    @Bean
    CommandLineRunner seedProducts(ProductRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new Product(null, "Chocolate Cake", new BigDecimal("650.00")));
                repository.save(new Product(null, "Red Velvet Cake", new BigDecimal("750.00")));
                repository.save(new Product(null, "Cupcake Box (6)", new BigDecimal("300.00")));
                repository.save(new Product(null, "Brownie Box (6)", new BigDecimal("350.00")));
            }
        };
    }
}
