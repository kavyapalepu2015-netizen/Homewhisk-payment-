package com.bakery.controller;

import com.bakery.dto.CreateOrderRequest;
import com.bakery.dto.OrderResponse;
import com.bakery.entity.OrderStatus;
import com.bakery.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:5173")
public class OrderController {
    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public OrderResponse create(@Valid @RequestBody CreateOrderRequest request) {
        return service.create(request);
    }

    @GetMapping
    public List<OrderResponse> all() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public OrderResponse byId(@PathVariable Long id) {
        return service.findById(id);
    }

    @PatchMapping("/{id}/status")
    public OrderResponse updateStatus(@PathVariable Long id,
                                      @RequestParam OrderStatus status) {
        return service.updateStatus(id, status);
    }
}
