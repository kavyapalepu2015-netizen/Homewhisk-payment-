package com.bakery.service;

import com.bakery.dto.CreateOrderRequest;
import com.bakery.dto.OrderResponse;
import com.bakery.entity.Order;
import com.bakery.entity.OrderStatus;
import com.bakery.entity.Product;
import com.bakery.exception.ResourceNotFoundException;
import com.bakery.repository.OrderRepository;
import com.bakery.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderService {
    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository, ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
    }

    public OrderResponse create(CreateOrderRequest request) {
        Product product = productRepository.findById(request.productId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

        Order order = new Order();
        order.setProduct(product);
        order.setQuantity(request.quantity());
        order.setCustomization(request.customization() == null ? "" : request.customization().trim());
        order.setDeliveryDate(request.deliveryDate());
        order.setDeliveryAddress(request.deliveryAddress().trim());
        order.setContactName(request.contactName().trim());
        order.setContactPhone(request.contactPhone().trim());
        order.setContactEmail(request.contactEmail().trim());
        order.setTotal(product.getPrice().multiply(BigDecimal.valueOf(request.quantity())));
        order.setStatus(OrderStatus.PENDING);

        return toResponse(orderRepository.save(order));
    }

    public List<OrderResponse> findAll() {
        return orderRepository.findAll().stream().map(this::toResponse).toList();
    }

    public OrderResponse findById(Long id) {
        return toResponse(orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found")));
    }

    public OrderResponse updateStatus(Long id, OrderStatus status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        order.setStatus(status);
        return toResponse(orderRepository.save(order));
    }

    private OrderResponse toResponse(Order o) {
        return new OrderResponse(
                o.getId(), o.getProduct().getName(), o.getProduct().getPrice(),
                o.getQuantity(), o.getCustomization(), o.getDeliveryDate(),
                o.getDeliveryAddress(), o.getContactName(), o.getContactPhone(),
                o.getContactEmail(), o.getTotal(), o.getStatus()
        );
    }
}
