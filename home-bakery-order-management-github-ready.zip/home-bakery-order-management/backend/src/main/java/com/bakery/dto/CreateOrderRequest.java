package com.bakery.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDate;

public record CreateOrderRequest(
        @NotNull(message = "Product is required")
        Long productId,

        @NotNull(message = "Quantity is required")
        @Min(value = 1, message = "Quantity must be at least 1")
        @Max(value = 50, message = "Quantity cannot exceed 50")
        Integer quantity,

        @Size(max = 1000, message = "Customization is too long")
        String customization,

        @NotNull(message = "Delivery date is required")
        @FutureOrPresent(message = "Delivery date cannot be in the past")
        LocalDate deliveryDate,

        @NotBlank(message = "Delivery address is required")
        @Size(max = 1000, message = "Delivery address is too long")
        String deliveryAddress,

        @NotBlank(message = "Contact name is required")
        @Size(max = 100, message = "Contact name is too long")
        String contactName,

        @NotBlank(message = "Contact phone is required")
        @Pattern(regexp = "^[0-9+()\\- ]{7,20}$", message = "Enter a valid phone number")
        String contactPhone,

        @NotBlank(message = "Contact email is required")
        @Email(message = "Enter a valid email address")
        String contactEmail
) {}
