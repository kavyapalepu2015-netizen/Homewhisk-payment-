package com.bakery.dto;

import com.bakery.entity.OrderStatus;
import java.math.BigDecimal;
import java.time.LocalDate;

public record OrderResponse(
        Long id,
        String product,
        BigDecimal unitPrice,
        Integer quantity,
        String customization,
        LocalDate deliveryDate,
        String deliveryAddress,
        String contactName,
        String contactPhone,
        String contactEmail,
        BigDecimal total,
        OrderStatus status
) {}
