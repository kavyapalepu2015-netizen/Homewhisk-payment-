package com.bakery.entity;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    BAKING,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}
